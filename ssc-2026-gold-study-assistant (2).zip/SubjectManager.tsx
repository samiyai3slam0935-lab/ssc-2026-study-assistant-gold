
import React, { useState, useEffect } from 'react';
import { Subject, SubTask, Chapter } from './types';

function createSubTasks(): SubTask[] {
  return [
    { id: 'basic', label: 'Basic', completed: false },
    { id: 'mcq', label: 'MCQ', completed: false },
    { id: 'cq', label: 'CQ', completed: false },
    { id: 'sq', label: 'SQ', completed: false },
  ];
}

function mapChapters(chapterNames: string[]): Chapter[] {
  return chapterNames.map((name, i) => ({
    id: `chap-${Date.now()}-${i}`,
    name,
    subTasks: createSubTasks()
  }));
}

const INITIAL_SUBJECTS: Subject[] = [
  { 
    id: 'math', 
    name: 'Mathematics', 
    chapters: mapChapters(["সেট ও ফাংশন", "বীজগাণিতিক রাশি", "ব্যবহারিক জ্যামিতি", "বৃত্ত", "ত্রিকোণমিতিক অনুপাত", "বীজগাণিতিক অনুপাত ও সমানুপাত", "পরিমিতি", "পরিসংখ্যান"]) 
  },
  { 
    id: 'b1', 
    name: 'Bangla 1st', 
    chapters: mapChapters([
      "প্রত্যুপকার", "শুভা", "বই পড়া", "আম-আঁটির ভেপু", "মানুষ মুহম্মদ (স.)", "নিমগাছ", "শিক্ষা ও মনুষ্যত্ব", "প্রবাস বন্ধু", "একুশের গল্প",
      "কপোতাক্ষ নদ", "জীবন বিনিময়", "উমর ফারুক", "সেইদিন এই মাঠ", "পল্লী জননী", "আমি কোনো আগন্তুক নই", "তোমাকে পাওয়ার জন্যে হে স্বাধীনতা"
    ]) 
  },
  { 
    id: 'b2', 
    name: 'Bangla 2nd', 
    chapters: mapChapters([
      "ধ্বনি ও বর্ণ", "স্বরধ্বনি", "ব্যঞ্জনধ্বনি", "বর্ণের উচ্চারণ", "শব্দ ও পদের গঠন", "উপসর্গ", "প্রত্যয়", "সমাস", "শব্দের শ্রেণিবিভাগ", "বিশেষ্য", "সর্বনাম", "বিশেষণ", "ক্রিয়া", "ক্রিয়াবিশেষণ", "অনুসর্গ", "যোজক", "আবেগ", "বাক্য", "উদ্দেশ্য ও বিধেয়", "বাচ্য", "বাগর্থ"
    ]) 
  },
  { 
    id: 'phys', 
    name: 'Physics', 
    chapters: mapChapters(["ভৌত রাশি ও পরিমাপ", "গতি", "বল", "কাজ ক্ষমতা ও শক্তি", "তরঙ্গ ও শব্দ", "আলোর প্রতিফলন", "স্থির বিদ্যুৎ"]) 
  },
  { 
    id: 'chem', 
    name: 'Chemistry', 
    chapters: mapChapters(["পদার্থের গঠন", "পর্যায় সারণি", "রাসায়নিক বন্ধন", "মোলের ধারণা ও রাসায়নিক গণনা", "রাসায়নিক বিক্রিয়া", "খনিজ সম্পদ (জীবাশ্ম)"]) 
  },
  { 
    id: 'bio', 
    name: 'Biology', 
    chapters: mapChapters(["জীবন পাঠ", "জীবকোষ ও টিস্যু", "কোষ বিভাজন", "জীবনীশক্তি", "জীবের প্রজনন", "জীবের বংশগতি ও বিবর্তন", "জীবের পরিবেশ"]) 
  },
  { 
    id: 'ags', 
    name: 'AGS', 
    chapters: mapChapters(["কৃষি প্রযুক্তি", "কৃষি উপকরণ", "কৃষিজ উৎপাদন", "বনায়ন"]) 
  },
  { 
    id: 'ict', 
    name: 'ICT', 
    chapters: mapChapters(["컴্পিউটার রক্ষণাবেক্ষণ ও সাইবার নিরাপত্তা", "আমার লেখালেখি ও হিসাব", "মাল্টিমিডিয়া ও গ্রাফিক্স", "প্রোগ্রামিং"]) 
  },
  { 
    id: 'islam', 
    name: 'Islam Studies', 
    chapters: mapChapters(["আকাইদ ও নৈতিক জীবন", "শরীয়তের উৎস", "ইবাদত", "আখলাক", "আদর্শ জীবনচরিত"]) 
  },
  { 
    id: 'bgs', 
    name: 'BGS', 
    chapters: mapChapters(["বাংলাদেশের স্বাধীনতা", "সৌরজগৎ ও ভূমন্ডল", "রাষ্ট্র নাগরিকতা ও আইন", "জাতীয় সম্পদ ও অর্থনৈতিক ব্যবস্থা", "অর্থনৈতিক নির্দেশকসমূহ", "বাংলাদেশের পরিবার কাঠামো ও সামাজিকীকরণ"]) 
  },
  { 
    id: 'e1', 
    name: 'English 1st', 
    chapters: [], // Empty for manual input
    manualInput: true 
  },
  { 
    id: 'e2', 
    name: 'English 2nd', 
    chapters: [], // Empty for manual input
    manualInput: true 
  },
];

interface SubjectManagerProps {
  onSelectSubject: (id: string) => void;
}

const SubjectManager: React.FC<SubjectManagerProps> = ({ onSelectSubject }) => {
  const [subjects, setSubjects] = useState<Subject[]>(() => {
    const saved = localStorage.getItem('ssc_subjects_data');
    return saved ? JSON.parse(saved) : INITIAL_SUBJECTS;
  });

  useEffect(() => {
    localStorage.setItem('ssc_subjects_data', JSON.stringify(subjects));
  }, [subjects]);

  const getSubProgress = (sub: Subject) => {
    if (sub.chapters.length === 0) return 0;
    let total = 0;
    sub.chapters.forEach(chap => {
      const completed = chap.subTasks.filter(t => t.completed).length;
      total += (completed / 4) * 100;
    });
    return Math.round(total / sub.chapters.length);
  };

  return (
    <div className="grid grid-cols-2 gap-4">
      {subjects.map((sub, idx) => {
        const progress = getSubProgress(sub);
        return (
          <button 
            key={sub.id}
            onClick={() => onSelectSubject(sub.id)}
            className="bg-[#0f172a]/40 border border-slate-800 rounded-3xl p-5 text-left group transition-all hover:bg-slate-900/60 hover:border-amber-500/30 relative overflow-hidden"
            style={{ animationDelay: `${idx * 0.03}s` }}
          >
            <div className={`absolute top-0 left-0 w-1 h-full ${progress === 100 ? 'bg-emerald-500' : 'bg-amber-500/40'}`}></div>
            <h3 className="text-[11px] font-black text-slate-300 mb-2 truncate group-hover:text-amber-400 transition-colors uppercase tracking-tight">
              {sub.name}
            </h3>
            
            <div className="flex justify-between items-end">
               <span className={`text-xl font-black tabular-nums transition-colors ${progress === 100 ? 'text-emerald-500' : 'text-amber-500'}`}>
                 {progress}%
               </span>
               <div className="w-16 h-1 bg-slate-950 rounded-full overflow-hidden mb-1">
                 <div 
                   className={`h-full transition-all duration-1000 ${progress === 100 ? 'bg-emerald-500' : 'bg-amber-500'}`} 
                   style={{ width: `${progress}%` }} 
                 />
               </div>
            </div>
          </button>
        );
      })}
    </div>
  );
};

export default SubjectManager;
