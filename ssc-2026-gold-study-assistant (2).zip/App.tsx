
import React, { useState, useEffect } from 'react';
import { NavTab, Subject } from './types';
import Home from './components/Home';
import Notes from './components/Notes';
import AIGuide from './components/AIGuide';
import Routine from './components/Routine';
import BottomNav from './BottomNav';
import SubjectDetail from './components/SubjectDetail';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<NavTab>(NavTab.Home);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [selectedSubjectId, setSelectedSubjectId] = useState<string | null>(null);

  const handleTabChange = (tab: NavTab) => {
    if (tab === activeTab) return;
    setIsTransitioning(true);
    setSelectedSubjectId(null);
    setTimeout(() => {
      setActiveTab(tab);
      setIsTransitioning(false);
    }, 250); 
  };

  const renderContent = () => {
    if (selectedSubjectId && activeTab === NavTab.Home) {
      return <SubjectDetail subjectId={selectedSubjectId} onBack={() => setSelectedSubjectId(null)} />;
    }

    switch (activeTab) {
      case NavTab.Home:
        return <Home onSelectSubject={setSelectedSubjectId} />;
      case NavTab.Notes:
        return <Notes />;
      case NavTab.AIGuide:
        return <AIGuide />;
      case NavTab.Routine:
        return <Routine />;
      default:
        return <Home onSelectSubject={setSelectedSubjectId} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#020617] pb-24 text-slate-100 flex flex-col w-full max-w-md mx-auto shadow-[0_0_100px_rgba(0,0,0,0.5)] relative overflow-x-hidden border-x border-slate-900/50 sm:border-slate-900">
      <header className="p-6 bg-[#020617]/95 backdrop-blur-xl sticky top-0 z-50 border-b border-slate-800/40 animate-medium-up">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-black tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-amber-200">
              SSC 2026 <span className="text-amber-400 italic font-light text-sm tracking-widest ml-1">GOLD</span>
            </h1>
            <p className="text-[9px] text-slate-500 font-bold uppercase tracking-[0.3em] mt-1">NCTB Study Companion</p>
          </div>
          <div className="w-10 h-10 rounded-2xl bg-slate-900 border border-slate-800/60 flex items-center justify-center text-xl animate-medium-in shadow-[0_0_15px_rgba(251,191,36,0.2)]">
            🌟
          </div>
        </div>
      </header>

      <main key={activeTab + (selectedSubjectId || '')} className={`flex-1 overflow-y-auto px-5 py-8 custom-scrollbar transition-all duration-300 ${isTransitioning ? 'opacity-0 translate-y-2' : 'opacity-100 translate-y-0'}`}>
        {renderContent()}
      </main>

      {!selectedSubjectId && (
        <div className="animate-nav-reveal">
          <BottomNav activeTab={activeTab} setActiveTab={handleTabChange} />
        </div>
      )}
    </div>
  );
};

export default App;
