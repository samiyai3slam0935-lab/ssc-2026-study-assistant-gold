
import React, { useState, useEffect } from 'react';

interface SubjectProgress {
  name: string;
  progress: number;
  color: string;
  secondaryColor: string;
}

const SyllabusProgress: React.FC = () => {
  const [overallProgress, setOverallProgress] = useState(() => {
    const saved = localStorage.getItem('ssc_progress');
    return saved ? parseInt(saved, 10) : 45;
  });

  const [subjects, setSubjects] = useState<SubjectProgress[]>(() => {
    const saved = localStorage.getItem('ssc_subject_progress');
    return saved ? JSON.parse(saved) : [
      { name: 'Physics', progress: 65, color: '#3b82f6', secondaryColor: '#1d4ed8' },
      { name: 'Higher Math', progress: 40, color: '#10b981', secondaryColor: '#047857' },
      { name: 'Chemistry', progress: 55, color: '#a855f7', secondaryColor: '#7e22ce' },
      { name: 'Biology', progress: 42, color: '#f43f5e', secondaryColor: '#be123c' }
    ];
  });

  useEffect(() => {
    localStorage.setItem('ssc_progress', overallProgress.toString());
    localStorage.setItem('ssc_subject_progress', JSON.stringify(subjects));
  }, [overallProgress, subjects]);

  const updateSubjectProgress = (index: number, value: number) => {
    const newSubjects = [...subjects];
    newSubjects[index].progress = value;
    setSubjects(newSubjects);
    
    const total = newSubjects.reduce((acc, curr) => acc + curr.progress, 0);
    setOverallProgress(Math.round(total / newSubjects.length));
  };

  // Circular progress math
  const size = 220;
  const center = size / 2;
  const strokeWidth = 16;
  const radius = center - strokeWidth;
  const circumference = 2 * Math.PI * radius;
  // Ensuring the offset calculation is mathematically perfect
  const offset = circumference - (overallProgress / 100) * circumference;

  return (
    <div className="bg-[#0f172a]/60 p-8 rounded-[3rem] border border-slate-800/80 shadow-[0_20px_50px_rgba(0,0,0,0.3)] backdrop-blur-2xl relative overflow-hidden group">
      {/* Dynamic Background Glow */}
      <div className="absolute -top-24 -left-24 w-64 h-64 bg-blue-600/10 blur-[100px] rounded-full group-hover:bg-blue-600/20 transition-all duration-1000"></div>
      
      <div className="flex flex-col items-center mb-10 relative">
        <div className="relative" style={{ width: size, height: size }}>
          {/* Inner Shadow and Depth Ring */}
          <div className="absolute inset-[18px] rounded-full border border-slate-800/20 shadow-[inset_0_2px_10px_rgba(0,0,0,0.5)] bg-[#020617]/40"></div>
          
          <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="transform -rotate-90 filter drop-shadow-[0_0_15px_rgba(59,130,246,0.3)]">
            <defs>
              <linearGradient id="mainProgressGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#60a5fa" />
                <stop offset="50%" stopColor="#3b82f6" />
                <stop offset="100%" stopColor="#2563eb" />
              </linearGradient>
              <filter id="glow">
                <feGaussianBlur stdDeviation="4" result="coloredBlur"/>
                <feMerge>
                    <feMergeNode in="coloredBlur"/>
                    <feMergeNode in="SourceGraphic"/>
                </feMerge>
              </filter>
            </defs>
            
            {/* Background Track Circle */}
            <circle
              cx={center}
              cy={center}
              r={radius}
              stroke="#1e293b"
              strokeWidth={strokeWidth}
              fill="transparent"
              strokeLinecap="round"
              className="opacity-40"
            />
            
            {/* Progress Circle with Liquid Animation */}
            <circle
              cx={center}
              cy={center}
              r={radius}
              stroke="url(#mainProgressGradient)"
              strokeWidth={strokeWidth}
              fill="transparent"
              strokeDasharray={circumference}
              strokeDashoffset={offset}
              strokeLinecap="round"
              filter="url(#glow)"
              className="transition-all duration-[2000ms]"
              style={{ transitionTimingFunction: 'cubic-bezier(0.4, 0, 0.2, 1)' }}
            />
          </svg>
          
          {/* Central Text Area */}
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <div className="flex items-start">
              <span className="text-6xl font-black text-white tracking-tighter drop-shadow-[0_4px_4px_rgba(0,0,0,0.5)]">
                {overallProgress}
              </span>
              <span className="text-blue-400 text-2xl font-bold mt-2">%</span>
            </div>
            <div className="bg-blue-500/10 border border-blue-500/20 px-3 py-1 rounded-full mt-2 animate-pulse">
              <span className="text-[10px] text-blue-300 font-black uppercase tracking-[0.2em]">Ready for SSC</span>
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-[11px] font-black text-slate-400 uppercase tracking-[0.3em] flex items-center gap-2">
            <div className="w-2 h-2 bg-blue-500 rounded-full shadow-[0_0_8px_#3b82f6]"></div>
            Subject Breakdown
          </h3>
          <span className="text-[10px] text-slate-500 font-bold bg-slate-900/50 px-2 py-1 rounded border border-slate-800">SSC 2026 TARGET</span>
        </div>

        <div className="grid grid-cols-1 gap-5">
          {subjects.map((sub, idx) => (
            <div key={sub.name} className="relative group/item">
              <div className="flex justify-between items-center mb-2 px-1">
                <span className="text-sm font-bold text-slate-300 group-hover/item:text-white transition-colors">
                  {sub.name}
                </span>
                <span className="text-xs font-mono font-black text-blue-400/80">
                  {sub.progress}%
                </span>
              </div>
              
              <div className="relative h-3 w-full bg-slate-950/80 rounded-full border border-slate-800/40 p-[2px] shadow-inner overflow-hidden">
                <div 
                  className="h-full rounded-full transition-all duration-[1500ms] ease-out relative"
                  style={{ 
                    width: `${sub.progress}%`, 
                    background: `linear-gradient(90deg, ${sub.secondaryColor}, ${sub.color})`,
                    boxShadow: `0 0 15px ${sub.color}44`
                  }}
                >
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                  <div className="absolute top-0 left-0 right-0 h-[1px] bg-white/20"></div>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={sub.progress}
                  onChange={(e) => updateSubjectProgress(idx, parseInt(e.target.value, 10))}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-20"
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Motivational Footer */}
      <div className="mt-10 pt-6 border-t border-slate-800/50 flex flex-col items-center gap-2">
        <div className="text-[10px] text-slate-500 font-bold uppercase tracking-widest italic opacity-60">
          "Consistency is the key to mastery"
        </div>
        <div className="flex gap-2">
          <div className="w-1 h-1 rounded-full bg-slate-700"></div>
          <div className="w-1 h-1 rounded-full bg-slate-700"></div>
          <div className="w-1 h-1 rounded-full bg-slate-700"></div>
        </div>
      </div>
    </div>
  );
};

export default SyllabusProgress;
