
import React, { useState, useEffect } from 'react';
import Countdown from './Countdown';
import SubjectManager from '../SubjectManager';
import { Subject } from '../types';

interface HomeProps {
  onSelectSubject: (id: string) => void;
}

interface WeakSubject {
  name: string;
  progress: number;
}

const Home: React.FC<HomeProps> = ({ onSelectSubject }) => {
  const [overallPercent, setOverallPercent] = useState(0);
  const [weakSubjects, setWeakSubjects] = useState<WeakSubject[]>([]);

  const calculateData = () => {
    const saved = localStorage.getItem('ssc_subjects_data');
    if (!saved) return { percent: 0, weak: [] };
    const subjects: Subject[] = JSON.parse(saved);
    
    let totalProgress = 0;
    const subList: WeakSubject[] = [];

    subjects.forEach(sub => {
      let subProgress = 0;
      if (sub.chapters.length > 0) {
        sub.chapters.forEach(chap => {
          const completedCount = chap.subTasks.filter(t => t.completed).length;
          subProgress += (completedCount / 4) * 100;
        });
        const finalSubProg = Math.round(subProgress / sub.chapters.length);
        totalProgress += finalSubProg;
        subList.push({ name: sub.name, progress: finalSubProg });
      } else {
        subList.push({ name: sub.name, progress: 0 });
      }
    });

    const weak = subList.sort((a, b) => a.progress - b.progress).slice(0, 3);
    return { 
      percent: subjects.length > 0 ? Math.round(totalProgress / subjects.length) : 0, 
      weak 
    };
  };

  useEffect(() => {
    const data = calculateData();
    setOverallPercent(data.percent);
    setWeakSubjects(data.weak);

    const handleStorage = () => {
      const updated = calculateData();
      setOverallPercent(updated.percent);
      setWeakSubjects(updated.weak);
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  return (
    <div className="space-y-12 pb-10">
      {/* Mastery Level Header - Updated to Gold Theme */}
      <section className="animate-slide-up">
        <div className="flex justify-between items-end mb-4">
          <div>
            <h2 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">Mastery Level</h2>
            <p className="text-xs text-slate-400 font-medium italic mt-1">Syllabus Completion</p>
          </div>
          <span className="text-5xl font-black text-amber-500 drop-shadow-[0_0_15px_rgba(245,158,11,0.3)]">{overallPercent}%</span>
        </div>
        <div className="h-4 w-full bg-slate-900 rounded-full border border-slate-800/50 p-1 shadow-inner overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-amber-600 to-yellow-400 rounded-full transition-all duration-1000 shadow-[0_0_10px_rgba(245,158,11,0.5)]" 
            style={{ width: `${overallPercent}%` }} 
          />
        </div>
      </section>

      {/* Subjects Grid */}
      <section className="animate-slide-up delay-100">
        <SubjectManager onSelectSubject={onSelectSubject} />
      </section>

      {/* Weakness Analysis Section - Updated to Gold Theme */}
      <section className="animate-slide-up delay-200">
        <div className="flex items-center gap-3 mb-6">
          <div className="h-[2px] w-6 bg-amber-600"></div>
          <h2 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">Weakness Analysis</h2>
        </div>
        
        <div className="bg-[#0f172a]/40 border border-slate-800/60 rounded-[2.5rem] p-6 backdrop-blur-md">
          <div className="space-y-6">
            {weakSubjects.map((sub, i) => (
              <div key={i} className="space-y-2">
                <div className="flex justify-between text-xs font-bold text-slate-300">
                  <span>{sub.name}</span>
                  <span className="text-amber-500">{sub.progress}%</span>
                </div>
                <div className="h-1 w-full bg-slate-950 rounded-full overflow-hidden">
                  <div className="h-full bg-amber-500/40" style={{ width: `${sub.progress}%` }} />
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-8 flex items-center gap-4 bg-amber-500/5 border border-amber-500/20 p-4 rounded-2xl">
            <span className="text-lg">⚡</span>
            <p className="text-[10px] font-black text-amber-500/80 uppercase tracking-widest leading-relaxed">
              Stay Focused! Dedicate more time here.
            </p>
          </div>
        </div>
      </section>

      {/* Revision Radar */}
      <section className="animate-slide-up delay-300">
        <div className="flex items-center gap-3 mb-6">
          <div className="h-[2px] w-6 bg-amber-500"></div>
          <h2 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">Revision Radar (7D Cycle)</h2>
        </div>
        <div className="bg-[#0f172a]/20 border border-slate-800/40 border-dashed rounded-[2.5rem] py-12 flex items-center justify-center">
           <span className="text-[10px] font-black text-slate-700 uppercase tracking-widest">No Active Revision Cycles</span>
        </div>
      </section>

      {/* Prep Timeline (Countdown) */}
      <section className="animate-slide-up delay-400">
        <div className="flex items-center gap-3 mb-6">
          <div className="h-[2px] w-3 bg-blue-500 rounded-full"></div>
          <h2 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">Prep Timeline</h2>
        </div>
        <Countdown targetDate="2026-04-21T00:00:00" />
      </section>
    </div>
  );
};

export default Home;
