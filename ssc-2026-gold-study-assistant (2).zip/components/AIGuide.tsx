
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { ChatMessage, ChatSession } from '../types';
import katex from 'katex';

const FormattedContent: React.FC<{ content: string }> = ({ content }) => {
  const renderMath = (text: string) => {
    if (!text) return null;
    const parts = text.split(/(\$\$.*?\$\$|\$.*?\$)/gs);
    return parts.map((part, index) => {
      try {
        if (part.startsWith('$$') && part.endsWith('$$')) {
          const math = part.slice(2, -2);
          return <div key={index} className="katex-display" dangerouslySetInnerHTML={{ __html: katex.renderToString(math, { displayMode: true, throwOnError: false }) }} />;
        } else if (part.startsWith('$') && part.endsWith('$')) {
          const math = part.slice(1, -1);
          return <span key={index} dangerouslySetInnerHTML={{ __html: katex.renderToString(math, { displayMode: false, throwOnError: false }) }} />;
        }
      } catch (e) { console.error(e); }
      return <span key={index}>{part}</span>;
    });
  };
  return <div className="math-rendered">{renderMath(content)}</div>;
};

const AIGuide: React.FC = () => {
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    const saved = localStorage.getItem('ssc_ai_sessions');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const activeSession = sessions.find(s => s.id === activeSessionId);
  const messages = activeSession ? activeSession.messages : [];

  useEffect(() => {
    localStorage.setItem('ssc_ai_sessions', JSON.stringify(sessions));
  }, [sessions]);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, isTyping]);

  const startNewChat = () => {
    setActiveSessionId(null);
    setShowHistory(false);
    setInput('');
    setSelectedImage(null);
  };

  const handleSend = async () => {
    if ((!input.trim() && !selectedImage) || isTyping) return;
    
    const userMsg: ChatMessage = { 
      role: 'user', 
      parts: input || (selectedImage ? "Analyze this image." : ""), 
      image: selectedImage || undefined 
    };

    let updatedSessions = [...sessions];
    let currentSessionId = activeSessionId;

    // Create new session if none active
    if (!currentSessionId) {
      currentSessionId = Date.now().toString();
      const newSession: ChatSession = {
        id: currentSessionId,
        title: input.slice(0, 30) || (selectedImage ? "Image Analysis" : "New Chat"),
        messages: [userMsg],
        timestamp: Date.now()
      };
      updatedSessions = [newSession, ...updatedSessions];
      setActiveSessionId(currentSessionId);
    } else {
      updatedSessions = updatedSessions.map(s => 
        s.id === currentSessionId ? { ...s, messages: [...s.messages, userMsg] } : s
      );
    }

    setSessions(updatedSessions);
    const curInput = input;
    const curImg = selectedImage;
    setInput('');
    setSelectedImage(null);
    setIsTyping(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      let finalMsg: ChatMessage;

      if (curInput.toLowerCase().includes('draw') || curInput.toLowerCase().includes('ছবি') || curInput.toLowerCase().includes('আঁকো')) {
        const res = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: { parts: [{ text: `Create an educational scientific illustration for SSC level: ${curInput}` }] }
        });
        const parts = res.candidates[0].content.parts;
        let img = "";
        let txt = "";
        for (const p of parts) {
          if (p.inlineData) img = `data:${p.inlineData.mimeType};base64,${p.inlineData.data}`;
          if (p.text) txt = p.text;
        }
        finalMsg = { role: 'model', parts: txt || "Here is your diagram:", generatedImage: img };
      } else if (curImg) {
        const base64 = curImg.split(',')[1];
        const mime = curImg.split(';')[0].split(':')[1];
        const res = await ai.models.generateContent({
          model: 'gemini-2.5-flash-image',
          contents: { parts: [{ inlineData: { data: base64, mimeType: mime } }, { text: `Solve this SSC problem or explain this study material. Use LaTeX for math. Query: ${curInput || "Explain this."}` }] }
        });
        finalMsg = { role: 'model', parts: responseToText(res) };
      } else {
        const res = await ai.models.generateContent({
          model: 'gemini-3-pro-preview',
          contents: curInput,
          config: { systemInstruction: "You are an SSC expert tutor. Use LaTeX. Be concise. Support Bengali and English." }
        });
        finalMsg = { role: 'model', parts: responseToText(res) };
      }

      setSessions(prev => prev.map(s => 
        s.id === currentSessionId ? { ...s, messages: [...s.messages, finalMsg] } : s
      ));
    } catch (e) {
      const errorMsg: ChatMessage = { role: 'model', parts: "Error in processing. Try again." };
      setSessions(prev => prev.map(s => 
        s.id === currentSessionId ? { ...s, messages: [...s.messages, errorMsg] } : s
      ));
    } finally { setIsTyping(false); }
  };

  const responseToText = (res: any) => res.text || "I couldn't generate a response.";

  const deleteSession = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setSessions(sessions.filter(s => s.id !== id));
    if (activeSessionId === id) setActiveSessionId(null);
  };

  return (
    <div className="flex flex-col h-[78vh] animate-slide-up relative">
      {/* Header with History Toggle */}
      <div className="flex items-center justify-between mb-4 px-1">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setShowHistory(!showHistory)}
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${showHistory ? 'bg-amber-500 text-slate-950' : 'bg-slate-900 text-slate-400 border border-slate-800'}`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" strokeWidth="2.5"/></svg>
          </button>
          <div>
            <h2 className="text-[10px] font-black text-amber-500 uppercase tracking-widest">AI Study Guide</h2>
            <p className="text-[9px] text-slate-500 font-bold truncate max-w-[150px]">
              {activeSession ? activeSession.title : 'New Learning Session'}
            </p>
          </div>
        </div>
        <button 
          onClick={startNewChat}
          className="bg-amber-600/10 border border-amber-600/20 text-amber-500 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-amber-600/20 transition-all"
        >
          + New Chat
        </button>
      </div>

      {/* History Sidebar/Overlay */}
      {showHistory && (
        <div className="absolute inset-0 z-50 bg-[#020617]/95 backdrop-blur-md animate-fade-in p-4 rounded-[2rem] border border-slate-800 shadow-2xl overflow-y-auto custom-scrollbar">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xs font-black text-slate-300 uppercase tracking-[0.2em]">Chat History</h3>
            <button onClick={() => setShowHistory(false)} className="text-slate-500 hover:text-white">✕</button>
          </div>
          <div className="space-y-3">
            {sessions.length === 0 ? (
              <p className="text-center py-10 text-[10px] text-slate-600 font-bold uppercase">No saved chats</p>
            ) : (
              sessions.map(s => (
                <div 
                  key={s.id}
                  onClick={() => { setActiveSessionId(s.id); setShowHistory(false); }}
                  className={`p-4 rounded-2xl border flex justify-between items-center group cursor-pointer transition-all ${activeSessionId === s.id ? 'bg-amber-500/10 border-amber-500/40' : 'bg-slate-900/40 border-slate-800 hover:border-slate-700'}`}
                >
                  <div className="flex-1 truncate mr-4">
                    <p className={`text-xs font-black truncate ${activeSessionId === s.id ? 'text-amber-400' : 'text-slate-300'}`}>{s.title}</p>
                    <span className="text-[8px] text-slate-600 font-bold uppercase mt-1 inline-block">
                      {new Date(s.timestamp).toLocaleDateString()}
                    </span>
                  </div>
                  <button 
                    onClick={(e) => deleteSession(e, s.id)}
                    className="opacity-0 group-hover:opacity-100 p-2 text-slate-600 hover:text-rose-500 transition-all"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" strokeWidth="2.5"/></svg>
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Messages Area */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-6 mb-4 custom-scrollbar px-1">
        {messages.length === 0 && (
          <div className="text-center py-16 opacity-50 flex flex-col items-center">
             <div className="w-20 h-20 bg-amber-500/5 rounded-3xl flex items-center justify-center mb-6 border border-amber-500/10 animate-pulse">
               <svg className="w-10 h-10 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0012 18.75c-1.03 0-1.9-.4-2.593-1.003l-.547-.547z" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
             </div>
             <p className="text-[10px] font-black uppercase tracking-[0.3em] text-amber-500/60 mb-2">Advanced Solver</p>
             <p className="text-[11px] text-slate-500 font-medium px-10">Ask any question, solve math problems with photos, or create study diagrams.</p>
          </div>
        )}
        
        {messages.map((m, i) => (
          <div key={i} className={`flex flex-col ${m.role === 'user' ? 'items-end' : 'items-start'}`}>
            <div className={`max-w-[90%] p-5 rounded-[2.2rem] text-sm shadow-xl transition-all ${
              m.role === 'user' 
                ? 'bg-amber-600 text-slate-950 rounded-br-none font-bold' 
                : 'bg-slate-900/90 border border-slate-800 text-slate-200 rounded-bl-none border-l-4 border-l-amber-500'
            }`}>
              {m.image && <img src={m.image} className="w-full rounded-2xl mb-3 border border-white/10" alt="Upload" />}
              <FormattedContent content={m.parts} />
              {m.generatedImage && (
                <div className="mt-4 relative group">
                  <img src={m.generatedImage} className="w-full rounded-2xl border border-amber-500/30" alt="Generated" />
                  <div className="absolute inset-0 bg-amber-500/10 opacity-0 group-hover:opacity-100 transition-opacity rounded-2xl pointer-events-none"></div>
                </div>
              )}
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex items-center gap-3 ml-2">
            <div className="flex gap-1">
              <span className="w-1.5 h-1.5 bg-amber-500 rounded-full animate-bounce"></span>
              <span className="w-1.5 h-1.5 bg-amber-500 rounded-full animate-bounce [animation-delay:0.2s]"></span>
              <span className="w-1.5 h-1.5 bg-amber-500 rounded-full animate-bounce [animation-delay:0.4s]"></span>
            </div>
            <span className="text-amber-500 text-[9px] font-black uppercase tracking-widest">Processing...</span>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="bg-[#0f172a]/60 p-2 rounded-[2.5rem] border border-slate-800/80 backdrop-blur-xl">
        {selectedImage && (
          <div className="flex items-center gap-3 p-3 bg-slate-950/80 rounded-2xl mb-2 mx-1 border border-amber-500/20">
            <img src={selectedImage} className="w-12 h-12 object-cover rounded-lg border border-amber-500" alt="Selected" />
            <div className="flex-1">
              <p className="text-[9px] font-black text-amber-500 uppercase">Image attached</p>
              <button onClick={() => setSelectedImage(null)} className="text-rose-500 text-[10px] font-black uppercase mt-0.5">Remove</button>
            </div>
          </div>
        )}
        <div className="flex gap-2">
          <button 
            onClick={() => fileInputRef.current?.click()} 
            className="w-12 h-12 bg-slate-950 rounded-2xl flex items-center justify-center text-slate-500 hover:text-amber-500 transition-all active:scale-90"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" strokeWidth="2"/><path d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" strokeWidth="2"/></svg>
          </button>
          <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            accept="image/*" 
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) { const r = new FileReader(); r.onloadend = () => setSelectedImage(r.result as string); r.readAsDataURL(f); }
            }} 
          />
          <input 
            value={input} 
            onChange={e => setInput(e.target.value)} 
            onKeyDown={e => e.key === 'Enter' && handleSend()} 
            placeholder="Ask anything or 'Draw a diagram'..." 
            className="flex-1 bg-transparent px-4 text-sm text-white focus:outline-none placeholder:text-slate-600 font-medium" 
          />
          <button 
            onClick={handleSend} 
            disabled={isTyping}
            className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all shadow-lg active:scale-90 ${isTyping ? 'bg-slate-800 text-slate-600' : 'bg-amber-600 text-slate-950 shadow-amber-900/20'}`}
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default AIGuide;
