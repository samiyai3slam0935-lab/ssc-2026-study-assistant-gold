import React, { useState, useEffect } from 'react';

interface CountdownProps {
  targetDate: string;
}

const Countdown: React.FC<CountdownProps> = ({ targetDate }) => {
  const [startDate, setStartDate] = useState<Date>(() => {
    const saved = localStorage.getItem('ssc_start_date');
    return saved ? new Date(saved) : new Date("2026-02-04T00:00:00");
  });

  const calculateTimeData = () => {
    const now = new Date();
    const endDate = new Date(targetDate);
    const diff = +endDate - +now;
    
    const totalDuration = +endDate - +startDate;
    const elapsed = +now - +startDate;
    const percent = Math.min(100, Math.max(0, (elapsed / totalDuration) * 100));

    return {
      days: Math.max(0, Math.floor(diff / (1000 * 60 * 60 * 24))),
      hours: Math.max(0, Math.floor((diff / (1000 * 60 * 60)) % 24)),
      minutes: Math.max(0, Math.floor((diff / 1000 / 60) % 60)),
      seconds: Math.max(0, Math.floor((diff / 1000) % 60)),
      totalPercent: percent
    };
  };

  const [time, setTime] = useState(calculateTimeData());

  useEffect(() => {
    const timer = setInterval(() => setTime(calculateTimeData()), 1000);
    return () => clearInterval(timer);
  }, [targetDate, startDate]);

  const TimeBlock = ({ val, label }: { val: number; label: string }) => (
    <div className="flex-1">
      <div className="bg-slate-900/40 border border-slate-800 rounded-full aspect-square flex flex-col items-center justify-center p-2 shadow-2xl relative overflow-hidden group">
        <div className="absolute inset-0 bg-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
        <span className="text-3xl font-black text-white tabular-nums drop-shadow-md">
          {val.toString().padStart(2, '0')}
        </span>
        <span className="text-[8px] uppercase font-black text-slate-600 tracking-widest mt-1">{label}</span>
      </div>
    </div>
  );

  return (
    <div className="space-y-10">
      <div className="flex gap-3 px-2">
        <TimeBlock val={time.days} label="Days" />
        <TimeBlock val={time.hours} label="Hours" />
        <TimeBlock val={time.minutes} label="Mins" />
        <TimeBlock val={time.seconds} label="Secs" />
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-end">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-1.5 h-1.5 rounded-full bg-cyan-500"></div>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Timeline Progress</span>
            </div>
            <span className="text-[10px] text-slate-500 font-bold">Started: 4 Feb 2026</span>
          </div>
          <div className="text-right">
            <span className="text-xl font-black text-blue-400 italic tabular-nums">{time.totalPercent.toFixed(3)}%</span>
            <p className="text-[9px] text-slate-600 font-black uppercase tracking-tighter">Time Elapsed</p>
          </div>
        </div>

        <div className="h-4 w-full bg-slate-950 rounded-full border border-slate-800/80 p-1 shadow-inner overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-blue-700 via-blue-500 to-cyan-400 rounded-full transition-all duration-1000"
            style={{ width: `${time.totalPercent}%` }}
          />
        </div>

        <div className="flex justify-between items-center pt-2">
          <button 
            onClick={() => {
              const now = new Date();
              setStartDate(now);
              localStorage.setItem('ssc_start_date', now.toISOString());
            }}
            className="text-[9px] font-black text-slate-600 uppercase tracking-widest bg-slate-900/50 px-4 py-2 rounded-xl border border-slate-800 hover:text-blue-400 transition-all flex items-center gap-2"
          >
            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" strokeWidth="3"/></svg>
            Restart Prep Session
          </button>
          <div className="text-right">
            <p className="text-[8px] text-slate-600 font-black uppercase tracking-widest">Target Date</p>
            <span className="text-[10px] text-white font-bold">21 April 2026</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Countdown;