
import React from 'react';

const Books: React.FC = () => {
  const subjects = [
    { name: 'Physics', icon: '⚛️', chapters: '14 Chapters' },
    { name: 'Chemistry', icon: '🧪', chapters: '12 Chapters' },
    { name: 'Higher Math', icon: '📐', chapters: '14 Chapters' },
    { name: 'General Math', icon: '➕', chapters: '17 Chapters' },
    { name: 'Biology', icon: '🧬', chapters: '14 Chapters' },
    { name: 'ICT', icon: '💻', chapters: '6 Chapters' },
  ];

  return (
    <div className="space-y-6">
      <header className="mb-4">
        <h2 className="text-2xl font-bold text-blue-400">NCTB Textbooks</h2>
        <p className="text-slate-400 text-sm">Quick access to your core curriculum subjects.</p>
      </header>

      <div className="grid grid-cols-2 gap-4">
        {subjects.map((sub) => (
          <div key={sub.name} className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col items-center text-center hover:border-blue-500/50 transition-colors cursor-pointer group">
            <div className="text-3xl mb-2 group-hover:scale-110 transition-transform">{sub.icon}</div>
            <h3 className="font-semibold text-sm">{sub.name}</h3>
            <span className="text-[10px] text-slate-500 uppercase mt-1">{sub.chapters}</span>
            <button className="mt-3 text-[10px] bg-slate-800 px-3 py-1 rounded-full text-blue-400 hover:bg-blue-600 hover:text-white transition-colors">
              Open PDF
            </button>
          </div>
        ))}
      </div>

      <div className="mt-8 p-4 bg-blue-900/20 border border-blue-800/50 rounded-xl">
        <h4 className="text-sm font-bold text-blue-300 mb-1">Coming Soon: Notes Library</h4>
        <p className="text-xs text-blue-400/80">Collaborative study notes from top SSC candidates across Bangladesh.</p>
      </div>
    </div>
  );
};

export default Books;
