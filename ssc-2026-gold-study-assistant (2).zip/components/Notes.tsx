
import React, { useState, useEffect } from 'react';
import { Note } from '../types';

const Notes: React.FC = () => {
  const [notes, setNotes] = useState<Note[]>(() => {
    const saved = localStorage.getItem('ssc_personal_notes');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [isAdding, setIsAdding] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  useEffect(() => {
    localStorage.setItem('ssc_personal_notes', JSON.stringify(notes));
  }, [notes]);

  const addNote = () => {
    if (!title.trim() || !content.trim()) return;
    const newNote: Note = {
      id: Date.now().toString(),
      title,
      content,
      date: new Date().toLocaleDateString('bn-BD')
    };
    setNotes([newNote, ...notes]);
    setTitle('');
    setContent('');
    setIsAdding(false);
  };

  const deleteNote = (id: string) => {
    setNotes(notes.filter(n => n.id !== id));
  };

  return (
    <div className="space-y-6 animate-medium-up">
      <header className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-black text-blue-400">ব্যক্তিগত নোটস</h2>
          <p className="text-slate-500 text-[10px] font-bold uppercase tracking-widest mt-1">Study Material & Thoughts</p>
        </div>
        <button 
          onClick={() => setIsAdding(!isAdding)}
          className={`w-12 h-12 rounded-2xl flex items-center justify-center text-white transition-all shadow-lg ${isAdding ? 'bg-rose-500 rotate-45' : 'bg-blue-600'}`}
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        </button>
      </header>

      {isAdding && (
        <div className="bg-slate-900/80 border border-blue-500/30 p-6 rounded-[2rem] space-y-4 animate-medium-in backdrop-blur-xl">
          <input
            type="text"
            placeholder="নোটের শিরোনাম (Title)"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm focus:outline-none focus:border-blue-500 transition-colors"
          />
          <textarea
            placeholder="আপনার কথা বা পড়ার বিষয় এখানে লিখুন..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            rows={5}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm focus:outline-none focus:border-blue-500 resize-none transition-colors"
          />
          <button 
            onClick={addNote}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl transition-colors shadow-lg shadow-blue-900/20"
          >
            নোট সেভ করুন
          </button>
        </div>
      )}

      <div className="space-y-4 pb-12">
        {notes.length === 0 && !isAdding && (
          <div className="py-20 flex flex-col items-center justify-center text-center opacity-30 animate-medium-in">
            <div className="w-20 h-20 bg-slate-800 rounded-full mb-4 flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 1 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
            </div>
            <p className="text-sm font-bold uppercase tracking-widest">কোনো নোট পাওয়া যায়নি</p>
          </div>
        )}
        
        {notes.map((note, idx) => (
          <div 
            key={note.id} 
            className="group bg-slate-900/40 border border-slate-800/50 p-5 rounded-[2rem] relative overflow-hidden transition-all hover:bg-slate-900/60 hover:border-blue-500/20 animate-medium-in"
            style={{ animationDelay: `${idx * 0.05}s` }}
          >
            <div className="flex justify-between items-start mb-3">
              <div>
                <h3 className="font-black text-blue-400 text-lg">{note.title}</h3>
                <span className="text-[10px] text-slate-600 font-bold uppercase tracking-tighter">{note.date}</span>
              </div>
              <button 
                onClick={() => deleteNote(note.id)}
                className="p-2 text-slate-700 hover:text-rose-500 transition-colors opacity-0 group-hover:opacity-100"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
              </button>
            </div>
            <p className="text-slate-300 text-sm leading-relaxed whitespace-pre-wrap">
              {note.content}
            </p>
            <div className="absolute top-0 right-0 w-16 h-16 bg-blue-500/5 blur-3xl pointer-events-none"></div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Notes;
