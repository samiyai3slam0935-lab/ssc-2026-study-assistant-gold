
import React, { useState, useEffect } from 'react';
import { WeeklyGoal } from '../types';

const Routine: React.FC = () => {
  const [goals, setGoals] = useState<WeeklyGoal[]>(() => {
    const saved = localStorage.getItem('ssc_weekly_goals');
    const initialDays = ['Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    return saved ? JSON.parse(saved) : initialDays.map((day, idx) => ({
      id: idx.toString(),
      day,
      goal: '',
      completed: false
    }));
  });

  useEffect(() => {
    localStorage.setItem('ssc_weekly_goals', JSON.stringify(goals));
  }, [goals]);

  const updateGoal = (id: string, text: string) => {
    setGoals(goals.map(g => g.id === id ? { ...g, goal: text } : g));
  };

  const toggleCompleted = (id: string) => {
    setGoals(goals.map(g => g.id === id ? { ...g, completed: !g.completed } : g));
  };

  return (
    <div className="space-y-6 animate-medium-up">
      <header className="mb-4">
        <h2 className="text-2xl font-black text-blue-400">সাপ্তাহিক পরিকল্পনা</h2>
        <p className="text-slate-500 text-sm mt-1">প্রতিদিনের পড়ার লক্ষ্য ঠিক করো</p>
      </header>

      <div className="space-y-4 pb-20">
        {goals.map((item, index) => (
          <div 
            key={item.id} 
            className="animate-medium-in bg-slate-900/40 border border-slate-800 rounded-2xl p-5 hover:border-blue-500/30 transition-all group"
            style={{ animationDelay: `${index * 0.05}s` }}
          >
            <div className="flex justify-between items-center mb-3">
              <span className="font-bold text-blue-400 flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                {item.day}
              </span>
              <button 
                onClick={() => toggleCompleted(item.id)}
                className={`text-[9px] uppercase font-black tracking-widest px-3 py-1 rounded-full border ${
                  item.completed 
                    ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' 
                    : 'bg-slate-800 text-slate-500 border-slate-700'
                }`}
              >
                {item.completed ? 'Done' : 'Pending'}
              </button>
            </div>
            <textarea
              value={item.goal}
              onChange={(e) => updateGoal(item.id, e.target.value)}
              placeholder={`${item.day}-এর পড়ার বিষয়...`}
              rows={2}
              className="w-full bg-slate-950/40 border border-slate-800 rounded-xl p-3 text-sm focus:outline-none focus:border-blue-500/40 resize-none text-slate-300"
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default Routine;
