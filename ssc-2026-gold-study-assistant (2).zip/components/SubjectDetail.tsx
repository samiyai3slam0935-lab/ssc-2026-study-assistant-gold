
import React, { useState, useEffect } from 'react';
import { Subject, Chapter, SubTask } from '../types';

interface SubjectDetailProps {
  subjectId: string;
  onBack: () => void;
}

const SubjectDetail: React.FC<SubjectDetailProps> = ({ subjectId, onBack }) => {
  const [subjects, setSubjects] = useState<Subject[]>(() => {
    const saved = localStorage.getItem('ssc_subjects_data');
    return saved ? JSON.parse(saved) : [];
  });

  const [subject, setSubject] = useState<Subject | undefined>(
    subjects.find(s => s.id === subjectId)
  );

  const [newChapterName, setNewChapterName] = useState('');
  const [isAdding, setIsAdding] = useState(false);

  useEffect(() => {
    if (subject) {
      const updatedSubjects = subjects.map(s => s.id === subject.id ? subject : s);
      setSubjects(updatedSubjects);
      localStorage.setItem('ssc_subjects_data', JSON.stringify(updatedSubjects));
      window.dispatchEvent(new Event('storage'));
    }
  }, [subject]);

  const addChapter = () => {
    if (!newChapterName.trim() || !subject) return;
    const newChap: Chapter = {
      id: Date.now().toString(),
      name: newChapterName,
      subTasks: [
        { id: 'basic', label: 'Basic', completed: false },
        { id: 'mcq', label: 'MCQ', completed: false },
        { id: 'cq', label: 'CQ', completed: false },
        { id: 'sq', label: 'SQ', completed: false },
      ]
    };
    setSubject({ ...subject, chapters: [...subject.chapters, newChap] });
    setNewChapterName('');
    setIsAdding(false);
  };

  const toggleTask = (chapterId: string, taskId: string) => {
    if (!subject) return;
    const newChapters = subject.chapters.map(chap => {
      if (chap.id === chapterId) {
        const updatedSubTasks = chap.subTasks.map(t => t.id === taskId ? { ...t, completed: !t.completed } : t);
        const allDone = updatedSubTasks.every(t => t.completed);
        
        return {
          ...chap,
          subTasks: updatedSubTasks,
          completedAt: allDone ? (chap.completedAt || new Date().toISOString()) : undefined
        };
      }
      return chap;
    });
    setSubject({ ...subject, chapters: newChapters });
  };

  const getChapProgress = (chap: Chapter) => {
    const completed = chap.subTasks.filter(t => t.completed).length;
    return (completed / 4) * 100;
  };

  if (!subject) return null;

  return (
    <div className="animate-slide-up">
      <header className="flex items-center gap-4 mb-8">
        <button 
          onClick={onBack}
          className="w-10 h-10 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-center text-slate-400 hover:text-amber-500 transition-colors"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>
        </button>
        <div>
          <h2 className="text-2xl font-black text-amber-400 drop-shadow-sm">{subject.name}</h2>
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Chapters & Mastery</p>
        </div>
      </header>

      <div className="space-y-6 pb-24">
        <div className="mb-8">
          {isAdding ? (
            <div className="flex gap-2 animate-fade-in">
              <input 
                type="text" 
                value={newChapterName}
                onChange={(e) => setNewChapterName(e.target.value)}
                placeholder={subject.manualInput ? "Unit/Topic Name..." : "Chapter Name..."}
                className="flex-1 bg-slate-900 border border-slate-800 rounded-2xl px-5 py-4 text-sm text-white focus:border-amber-500 outline-none shadow-inner"
                autoFocus
              />
              <button onClick={addChapter} className="bg-amber-600 px-8 rounded-2xl font-black text-xs uppercase text-white shadow-lg active:scale-95 transition-all">Add</button>
              <button onClick={() => setIsAdding(false)} className="text-slate-500 p-2 hover:text-rose-500">✕</button>
            </div>
          ) : (
            <button 
              onClick={() => setIsAdding(true)}
              className="w-full py-5 border-2 border-dashed border-slate-800 rounded-[2rem] text-slate-500 font-black text-[10px] uppercase tracking-[0.2em] hover:border-amber-500/30 hover:text-amber-400 transition-all bg-slate-900/10"
            >
              + Add {subject.manualInput ? 'Unit / Topic' : 'Chapter'}
            </button>
          )}
        </div>

        {subject.chapters.length === 0 && (
          <div className="py-20 text-center opacity-30">
            <p className="text-xs font-black uppercase tracking-widest">No chapters added yet.</p>
          </div>
        )}

        {subject.chapters.map((chap, idx) => {
          const progress = getChapProgress(chap);
          const isFinished = progress === 100;
          
          return (
            <div key={chap.id} className="bg-[#0f172a]/40 border border-slate-800 rounded-[2.5rem] p-6 animate-slide-up" style={{ animationDelay: `${idx * 0.05}s` }}>
              <div className="flex justify-between items-start mb-5">
                <div className="flex-1">
                  <h4 className={`font-black pr-4 leading-tight transition-colors ${isFinished ? 'text-emerald-400' : 'text-slate-200'}`}>
                    {chap.name}
                  </h4>
                </div>
                <div className="text-right">
                  <span className={`text-xl font-black transition-all duration-500 ${isFinished ? 'text-emerald-500' : 'text-amber-500'} tabular-nums`}>
                    {progress}%
                  </span>
                </div>
              </div>

              <div className="h-2 w-full bg-slate-950 rounded-full overflow-hidden mb-6 p-[2px] border border-slate-800/50">
                <div 
                  className={`h-full rounded-full transition-all duration-1000 ease-out ${isFinished ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.3)]' : 'bg-amber-500 shadow-[0_0_10px_rgba(245,158,11,0.2)]'}`} 
                  style={{ width: `${progress}%` }} 
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                {chap.subTasks.map(task => (
                  <button 
                    key={task.id}
                    onClick={() => toggleTask(chap.id, task.id)}
                    className={`flex items-center gap-3 p-3.5 rounded-2xl border transition-all text-[10px] font-black uppercase tracking-widest ${
                      task.completed 
                        ? 'bg-amber-500/10 border-amber-500/40 text-amber-400' 
                        : 'bg-slate-950 border-slate-800/80 text-slate-600 hover:border-slate-700'
                    }`}
                  >
                    <div className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-all ${
                      task.completed ? 'bg-amber-500 border-amber-500 shadow-[0_0_12px_rgba(245,158,11,0.4)]' : 'border-slate-800 bg-slate-900'
                    }`}>
                      {task.completed && (
                        <svg className="w-3.5 h-3.5 text-slate-950" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4"><polyline points="20 6 9 17 4 12"/></svg>
                      )}
                    </div>
                    {task.label}
                  </button>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default SubjectDetail;
