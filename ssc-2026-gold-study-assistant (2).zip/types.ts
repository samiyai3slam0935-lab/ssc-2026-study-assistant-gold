
export interface Task {
  id: string;
  text: string;
  completed: boolean;
}

export interface WeeklyGoal {
  id: string;
  day: string;
  goal: string;
  completed: boolean;
}

export enum NavTab {
  Home = 'home',
  Notes = 'notes',
  AIGuide = 'ai_guide',
  Routine = 'routine'
}

export interface ChatMessage {
  role: 'user' | 'model';
  parts: string;
  image?: string;
  generatedImage?: string;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: ChatMessage[];
  timestamp: number;
}

export interface Note {
  id: string;
  title: string;
  content: string;
  date: string;
}

export interface SubTask {
  id: string;
  label: string;
  completed: boolean;
}

export interface Chapter {
  id: string;
  name: string;
  subTasks: SubTask[];
  completedAt?: string;
}

export interface Subject {
  id: string;
  name: string;
  chapters: Chapter[];
  manualInput?: boolean;
}
